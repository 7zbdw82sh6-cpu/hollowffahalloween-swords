@echo off
setlocal
title HalloweenSwords - Build

echo ==========================================
echo   HalloweenSwords - Maven Build
echo   Paper 1.21.11 / Java 21
echo ==========================================
echo.

where java >nul 2>&1
if errorlevel 1 (
    echo ERROR: Java was not found.
    echo Install a Java 21 JDK, then run this file again.
    echo.
    pause
    exit /b 1
)

for /f "tokens=2 delims=." %%A in ('java -version 2^>^&1 ^| findstr /i "version"') do set "JAVA_MAJOR=%%A"
echo Java detected. Maven will use the project's pom.xml.
echo.

if exist ".mvn\wrapper\maven-wrapper.jar" (
    set "MVNW_CMD=mvnw.cmd"
) else (
    where mvn >nul 2>&1
    if errorlevel 1 (
        echo Maven was not found and no Maven Wrapper is bundled.
        echo.
        echo Please install Maven or run this project through an IDE with Maven support.
        pause
        exit /b 1
    )
    set "MVNW_CMD=mvn"
)

call %MVNW_CMD% clean package
if errorlevel 1 (
    echo.
    echo BUILD FAILED.
    pause
    exit /b 1
)

echo.
echo BUILD COMPLETE!
echo.
echo JAR files:
dir /b target\*.jar
echo.
echo Your plugin JAR is in the target folder.
pause
