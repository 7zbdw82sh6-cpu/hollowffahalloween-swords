Maven Wrapper directory reserved for mvnw configuration. Maven must be installed unless a wrapper is supplied.
